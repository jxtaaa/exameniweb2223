
def exampleEntity(item) -> dict: 
    return{
        "id": item["id"],
        "name": item["name"],
        "description": item["description"]
    }
