class NotFoundError(Exception):
    error_code = 'NOT_FOUND'
